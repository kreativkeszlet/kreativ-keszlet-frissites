import sys, os, json, base64, io, random, time, threading, urllib.request, urllib.error, zipfile, tempfile, shutil, subprocess, re, ssl, certifi
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass
from pathlib import Path
from datetime import datetime
from PySide6.QtCore import Qt, QTimer, QSize, QObject, Signal
from PySide6.QtGui import QPixmap, QIcon, QFont, QColor, QPainter, QBrush
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QTabWidget, QLineEdit, QComboBox, QSpinBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QFileDialog, QDialog, QFormLayout,
    QCheckBox, QSlider, QGroupBox, QListWidget, QListWidgetItem, QAbstractItemView,
    QTextEdit, QDoubleSpinBox, QInputDialog, QScrollArea
)
from flask import Flask, request, jsonify, send_from_directory

APP='Kreatív Készlet'
APP_VERSION='36.3.0'
UPDATE_REPO='kreativkeszlet/kreativ-keszlet-frissites'
BASE=getattr(sys,'_MEIPASS',os.path.dirname(os.path.abspath(__file__)))
HOME=os.path.expanduser('~')
DATA=os.path.join(HOME,'KreativKeszlet_data.json')
SETTINGS=os.path.join(HOME,'KreativKeszlet_megjelenes.json')
FINANCE=os.path.join(HOME,'KreativKeszlet_penz.json')
DAILY=os.path.join(HOME,'KreativKeszlet_napi.json')
WEB=os.path.join(BASE,'ipad')
DEFAULT={'categories':['Festék','Papír','Csomagolás','Eszközök','Dekoráció','Egyéb'],'types':['Akril','Tinta','Vízfesték','Tempera','Gouache','Olajfesték','Textilfesték','Üvegfesték','Egyéb'],'items':[],'pencils':[],'shopping':[]}
DEFAULT_SETTINGS={'title':APP,'subtitle':'Minden kreatív kelléked egy helyen','image':'','image_name':'','image_dark':8,'glass_opacity':28,'messages':['Zsófi! Még mindig kupi van nálad? 😏','Zsófi, megint vettél festéket? 😂','A kupi nem kategória, Zsófi! 😜','Mindennek van helye. Valahol. 🤔','Zsófi, biztos tudod, melyik dobozban van?','Még egy festék? Tényleg szükséged van rá? 😏','Na, mit alkotunk ma? 🎨']}

def read_json(path, default):
    try:
        with open(path,'r',encoding='utf-8') as f:return json.load(f)
    except Exception:return json.loads(json.dumps(default))

data=read_json(DATA,DEFAULT)
for k,v in DEFAULT.items(): data.setdefault(k,list(v) if isinstance(v,list) else v)
settings=read_json(SETTINGS,DEFAULT_SETTINGS)
for k,v in DEFAULT_SETTINGS.items(): settings.setdefault(k,list(v) if isinstance(v,list) else v)
finance=read_json(FINANCE,{'paint_spend':0.0,'spends':[],'sales':[]})
finance.setdefault('spends',[]); finance.setdefault('sales',[])
# Régi verzióból megőrizzük az egyetlen korábbi festékköltség-összeget is, hogy ne vesszen el adat.
if not finance['spends'] and float(finance.get('paint_spend',0) or 0) != 0:
    finance['spends']=[{'amount':float(finance.get('paint_spend',0)),'date':'','note':'Korábbi összesítés'}]
finance['paint_spend']=sum(float(x.get('amount',0)) for x in finance['spends'])

def save_all():
    with open(DATA,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
    with open(SETTINGS,'w',encoding='utf-8') as f:json.dump(settings,f,ensure_ascii=False,indent=2)
    with open(FINANCE,'w',encoding='utf-8') as f:json.dump(finance,f,ensure_ascii=False,indent=2)

def money(v):
    try:n=float(v)
    except:n=0
    return f'{n:,.0f}'.replace(',',' ')

def total_spend():return sum(float(x.get('amount',0)) for x in finance.get('spends',[]))
def total_sales():return sum(float(x.get('price',0)) for x in finance.get('sales',[]))

# iPad/local server retained
server=Flask(__name__,static_folder=WEB)
@server.get('/')
def home():return send_from_directory(WEB,'index.html')
@server.get('/api/health')
def api_health():
    return jsonify({'ok':True,'app':'KreativKeszlet','version':'36'})

@server.get('/api/data')
def api_get():
    resp=jsonify({'data':data,'finance':finance,'settings':settings})
    resp.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'
    return resp
@server.post('/api/data')
def api_put():
    incoming=request.get_json(force=True)
    if not isinstance(incoming,dict):return jsonify(error='invalid'),400
    # Az iPad ugyanazt a helyi adatállományt használja, mint a PC.
    incoming_data=incoming.get('data', incoming)
    if isinstance(incoming_data,dict):
        data.update(incoming_data)
        data.setdefault('pencils',[]); data.setdefault('shopping',[])
    if isinstance(incoming.get('finance'),dict):
        finance.clear(); finance.update(incoming['finance'])
        finance.setdefault('spends',[]); finance.setdefault('sales',[])
        finance['paint_spend']=total_spend()
    if isinstance(incoming.get('settings'),dict):
        settings.update(incoming['settings'])
    save_all()
    return jsonify(ok=True)
@server.get('/<path:p>')
def static_files(p):return send_from_directory(WEB,p)
def run_server():server.run(host='0.0.0.0',port=8765,debug=False,use_reloader=False)
threading.Thread(target=run_server,daemon=True).start()

class GlassCard(QGroupBox):
    def __init__(self,title='',parent=None):
        super().__init__(title,parent); self.setObjectName('card')
        self.setStyleSheet('QGroupBox#card{background:rgba(255,255,255,165);border:1px solid rgba(255,255,255,210);border-radius:16px;margin-top:10px;padding:12px;}QGroupBox#card::title{subcontrol-origin:margin;left:14px;padding:0 7px;font-weight:700;color:#7d1720;}')

class UpdateSignals(QObject):
    result = Signal(object)


def version_tuple(tag):
    m=re.search(r'(\d+)\.(\d+)(?:\.(\d+))?', str(tag or ''))
    return tuple(int(x or 0) for x in m.groups()) if m else (0,0,0)


def update_is_newer(tag):
    return version_tuple(tag) > version_tuple(APP_VERSION)


def download_and_prepare_update(url, current_pid, target_dir):
    """Download a GitHub release ZIP and prepare a PowerShell installer."""
    tmp_root=tempfile.mkdtemp(prefix='KreativKeszlet_update_')
    zip_path=os.path.join(tmp_root,'KreativKeszlet-Windows.zip')
    extract_dir=os.path.join(tmp_root,'new')
    os.makedirs(extract_dir,exist_ok=True)
    req=urllib.request.Request(url,headers={'User-Agent':'KreativKeszlet-Updater','Accept':'application/octet-stream'})
    with urllib.request.urlopen(req,timeout=60,context=ssl.create_default_context(cafile=certifi.where())) as r, open(zip_path,'wb') as f:
        shutil.copyfileobj(r,f)
    with zipfile.ZipFile(zip_path,'r') as z: z.extractall(extract_dir)
    exe=os.path.join(extract_dir,'KreativKeszlet.exe')
    if not os.path.isfile(exe):
        candidates=list(Path(extract_dir).rglob('KreativKeszlet.exe'))
        if candidates:
            nested=candidates[0]
            for child in Path(nested.parent).iterdir():
                dest=Path(extract_dir)/child.name
                if child != dest:
                    shutil.copytree(child,dest,dirs_exist_ok=True) if child.is_dir() else shutil.copy2(child,dest)
            exe=str(Path(extract_dir)/'KreativKeszlet.exe')
    if not os.path.isfile(exe): raise RuntimeError('A letöltött frissítésben nem található a KreativKeszlet.exe.')
    ps=os.path.join(tmp_root,'update.ps1')
    def q(x): return "'"+str(x).replace("'","''")+"'"
    script = (
        '$ErrorActionPreference = "Stop"\n'
        f'$pidToWait = {int(current_pid)}\n'
        f'$source = {q(extract_dir)}\n'
        f'$target = {q(target_dir)}\n'
        'while (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 1 }\n'
        'Start-Sleep -Seconds 1\n'
        'Get-ChildItem -LiteralPath $source -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force }\n'
        "Start-Process -FilePath (Join-Path $target 'KreativKeszlet.exe')\n"
        f'Remove-Item -LiteralPath {q(tmp_root)} -Recurse -Force -ErrorAction SilentlyContinue\n'
    )
    Path(ps).write_text(script,encoding='utf-8')
    return ps


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(APP);self.resize(1280,820);self.setMinimumSize(1000,650)
        self.update_signals=UpdateSignals();self.update_signals.result.connect(self.handle_update_result)
        icon=os.path.join(BASE,'kreativ_keszlet.ico')
        if os.path.exists(icon):self.setWindowIcon(QIcon(icon))
        self._bg_pixmap=QPixmap()
        self._bg_scaled=QPixmap()
        self.central=QWidget();self.central.setObjectName('central');self.central.setAttribute(Qt.WA_TranslucentBackground, True);self.setCentralWidget(self.central)
        self.root=QVBoxLayout(self.central);self.root.setContentsMargins(26,22,26,18);self.root.setSpacing(12)
        self.build_header();self.tabs=QTabWidget();self.tabs.setDocumentMode(True);self.root.addWidget(self.tabs,1)
        self.build_inventory();self.build_pencils();self.build_shop();self.build_lists();self.build_finance();self.build_backup()
        self.footer=QLabel();self.footer.setAlignment(Qt.AlignCenter);self.root.addWidget(self.footer)
        self.apply_style();self.update_background();self.refresh_all()
        self.msg_timer=QTimer(self);self.msg_timer.timeout.connect(self.rotate_message);self.msg_timer.start(25000);self.rotate_message()
        self.clock=QTimer(self);self.clock.timeout.connect(self.daily_check);self.clock.start(30000);self.daily_check()
        QTimer.singleShot(2500,self.check_updates_auto)

    def build_header(self):
        h=QWidget();h.setObjectName('header');hl=QHBoxLayout(h);hl.setContentsMargins(20,12,16,12)
        text=QVBoxLayout();self.title=QLabel(settings.get('title',''));self.title.setObjectName('title');self.subtitle=QLabel(settings.get('subtitle',''));self.subtitle.setObjectName('subtitle');text.addWidget(self.title);text.addWidget(self.subtitle);hl.addLayout(text,1)
        for label,slot,obj in [('🎨 Megjelenés',self.appearance,'accent'),('💾 Mentés',self.backup_quick,'soft'),('🔄 Frissítés',self.check_updates_manual,'soft'),('＋ Új készlet',self.new_item,'accent')]:
            b=QPushButton(label);b.setObjectName(obj);b.clicked.connect(slot);hl.addWidget(b)
        self.root.addWidget(h)

    def make_tab(self,name):
        w=QWidget();w.setObjectName('page');w.setAttribute(Qt.WA_TranslucentBackground, True);lay=QVBoxLayout(w);lay.setContentsMargins(16,16,16,16);lay.setSpacing(10);self.tabs.addTab(w,name);return w,lay

    def build_inventory(self):
        w,l=self.make_tab('📦 Készlet')
        top=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('🔎 Keresés név, kategória, fajta, hely, megjegyzés alapján...');self.search.textChanged.connect(self.refresh_inventory);top.addWidget(self.search);clr=QPushButton('Keresés törlése');clr.clicked.connect(self.search.clear);top.addWidget(clr);l.addLayout(top)
        self.tree=QTableWidget(0,6);self.tree.setHorizontalHeaderLabels(['Megnevezés','Kategória','Fajta','Mennyiség','Egység','Hely']);self.tree.setSelectionBehavior(QAbstractItemView.SelectRows);self.tree.setEditTriggers(QAbstractItemView.NoEditTriggers);self.tree.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);l.addWidget(self.tree,1)
        row=QHBoxLayout();
        for txt,fn in [('Szerkesztés',self.edit_item),('🗑 Törlés',self.delete_item),('−1 mennyiség',lambda:self.change_qty(-1)),('+1 mennyiség',lambda:self.change_qty(1))]:b=QPushButton(txt);b.clicked.connect(fn);row.addWidget(b)
        row.addStretch();self.inv_count=QLabel();row.addWidget(self.inv_count);l.addLayout(row)

    def build_pencils(self):
        w,l=self.make_tab('✏️ Ceruzák');title=QLabel('✏️ Ceruzák');title.setObjectName('section');l.addWidget(title);l.addWidget(QLabel('Külön nyilvántartás a ceruzáknak és annak, melyik vált be.'))
        split=QHBoxLayout();l.addLayout(split,1)
        left=GlassCard('Ceruzák');ll=QVBoxLayout(left);self.pt=QTableWidget(0,5);self.pt.setHorizontalHeaderLabels(['Ceruza','Alkategória','Keménység','Használat','Bevált']);self.pt.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);self.pt.setSelectionBehavior(QAbstractItemView.SelectRows);self.pt.setEditTriggers(QAbstractItemView.NoEditTriggers);ll.addWidget(self.pt,1)
        br=QHBoxLayout();
        for t,f in [('＋ Új ceruza',self.new_pencil),('Szerkesztés',self.edit_pencil),('🗑 Törlés',self.delete_pencil)]:b=QPushButton(t);b.clicked.connect(f);br.addWidget(b)
        ll.addLayout(br);split.addWidget(left,1)
        right=GlassCard('⭐ Bevált / kedvenc ceruzák');rl=QVBoxLayout(right);self.favp=QTextEdit();self.favp.setReadOnly(True);rl.addWidget(self.favp);split.addWidget(right,1)

    def build_shop(self):
        w,l=self.make_tab('🛒 Bevásárlólista');self.shop=QListWidget();l.addWidget(self.shop,1);row=QHBoxLayout();self.shop_entry=QLineEdit();self.shop_entry.setPlaceholderText('Mit kell megvenni?');row.addWidget(self.shop_entry,1)
        for t,f in [('＋ Hozzáadás',self.add_shop),('☑ Megvettem',self.toggle_shop),('🗑 Törlés',self.delete_shop)]:b=QPushButton(t);b.clicked.connect(f);row.addWidget(b)
        l.addLayout(row)

    def build_lists(self):
        for key,title in [('categories','🗂 Kategóriák'),('types','🏷 Fajták')]:
            w,l=self.make_tab(title);lb=QListWidget();setattr(self,'lb_'+key,lb);l.addWidget(lb,1);row=QHBoxLayout();e=QLineEdit();e.setPlaceholderText('Új elem neve');setattr(self,'ent_'+key,e);row.addWidget(e,1)
            for t,fn in [('＋ Hozzáadás',lambda _,k=key:self.add_list(k)),('🗑 Törlés',lambda _,k=key:self.delete_list(k))]:b=QPushButton(t);b.clicked.connect(fn);row.addWidget(b)
            l.addLayout(row)

    def build_finance(self):
        w,l=self.make_tab('💰 Festék / bevétel');head=QLabel('💰 Festék költsége és festmények bevétele');head.setObjectName('section');l.addWidget(head);l.addWidget(QLabel('A festékekre költött összegeket és a festmények eladásait külön vezetheted.'))
        summ=QHBoxLayout();self.spend_sum=self.summary_card(summ,'🎨 Festékre');self.sale_sum=self.summary_card(summ,'💰 Bevétel');self.diff_sum=self.summary_card(summ,'📈 Különbség');l.addLayout(summ)
        grid=QGridLayout();l.addLayout(grid,1)
        a=GlassCard('🎨 Festékre költött összegek');al=QVBoxLayout(a);self.spends=QTableWidget(0,3);self.spends.setHorizontalHeaderLabels(['Dátum','Összeg','Megjegyzés']);self.spends.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);self.spends.setSelectionBehavior(QAbstractItemView.SelectRows);self.spends.setEditTriggers(QAbstractItemView.NoEditTriggers);al.addWidget(self.spends,1);rb=QHBoxLayout();x=QPushButton('＋ Hozzáadás');x.clicked.connect(self.add_spend);rb.addWidget(x);x=QPushButton('🗑 Törlés');x.clicked.connect(self.delete_spend);rb.addWidget(x);rb.addStretch();al.addLayout(rb);grid.addWidget(a,0,0)
        b=GlassCard('💰 Eladott festmények bevétele');bl=QVBoxLayout(b);self.sales=QTableWidget(0,4);self.sales.setHorizontalHeaderLabels(['Dátum','Összeg','Festmény','Megjegyzés']);self.sales.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);self.sales.setSelectionBehavior(QAbstractItemView.SelectRows);self.sales.setEditTriggers(QAbstractItemView.NoEditTriggers);bl.addWidget(self.sales,1);rb=QHBoxLayout();x=QPushButton('＋ Hozzáadás');x.clicked.connect(self.add_sale);rb.addWidget(x);x=QPushButton('🗑 Törlés');x.clicked.connect(self.delete_sale);rb.addWidget(x);rb.addStretch();bl.addLayout(rb);grid.addWidget(b,0,1)
        tip=QLabel('💡 Tipp: jelöld ki a hibás bejegyzést, majd töröld. Az összesítés automatikusan frissül.');tip.setObjectName('tip');l.addWidget(tip)

    def summary_card(self,row,label):
        f=GlassCard();q=QHBoxLayout(f);lab=QLabel(label);lab.setObjectName('summary');val=QLabel('0 Ft');val.setObjectName('summary');q.addWidget(lab);q.addWidget(val);f._value=val;row.addWidget(f,1);return f

    def build_backup(self):
        w,l=self.make_tab('💾 Mentés');l.addWidget(QLabel('💾 Biztonsági mentés',objectName='section'));l.addWidget(QLabel('Az adataidat, megjelenést és pénzügyi adatokat egy fájlba mentheted.'))
        for t,f in [('💾 Biztonsági mentés készítése',self.backup),('↩️ Biztonsági mentés visszaállítása',self.restore),('🖨️ Készletlista mentése',self.export_inventory)]:b=QPushButton(t);b.clicked.connect(f);l.addWidget(b);l.addStretch()

    def apply_style(self):
        op=max(12,min(70,int(settings.get('glass_opacity',28))));alpha=int(255*(1-op/100))
        self.setStyleSheet(f'''QMainWindow{{background:#eee5e5;}} QWidget#central{{background:transparent;}} QWidget#page{{background:transparent;}} QWidget#header{{background:rgba(255,255,255,{max(100,alpha)});border:1px solid rgba(255,255,255,220);border-radius:18px;}} QTabWidget::pane{{background:rgba(255,255,255,{min(180,alpha)});border:1px solid rgba(255,255,255,215);border-radius:16px;}} QTabBar::tab{{background:rgba(255,255,255,145);padding:12px 18px;border:1px solid rgba(255,255,255,180);margin-right:2px;color:#24191b;font-weight:600;}} QTabBar::tab:selected{{background:rgba(255,255,255,220);color:#b51f2c;border-bottom:3px solid #c93642;}} QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox,QTextEdit,QListWidget,QTableWidget{{background:rgba(255,255,255,205);border:1px solid rgba(255,255,255,230);border-radius:9px;padding:7px;color:#2d2022;}} QHeaderView::section{{background:rgba(255,255,255,210);padding:9px;border:0;font-weight:700;color:#3a2225;}} QPushButton{{background:rgba(255,255,255,205);border:1px solid rgba(255,255,255,230);border-radius:9px;padding:9px 14px;font-weight:600;color:#2e2224;}} QPushButton:hover{{background:rgba(255,255,255,235);}} QPushButton#accent{{background:#c93642;color:white;border:0;}} QPushButton#soft{{background:rgba(255,245,245,210);}} QLabel{{color:#2f2325;}} QLabel#title{{font-size:27px;font-weight:800;color:#351b20;}} QLabel#subtitle{{font-size:12px;color:#705b60;}} QLabel#section{{font-size:21px;font-weight:800;color:#861722;padding:4px;}} QLabel#summary{{font-size:18px;font-weight:800;color:#8b1823;}} QLabel#tip{{background:rgba(255,255,255,150);padding:9px;border-radius:9px;color:#594548;}}''')

    def resizeEvent(self,e):
        super().resizeEvent(e)
        self._rescale_background()

    def paintEvent(self,e):
        painter=QPainter(self)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        if not self._bg_scaled.isNull():
            x=(self.width()-self._bg_scaled.width())//2
            y=(self.height()-self._bg_scaled.height())//2
            painter.drawPixmap(x,y,self._bg_scaled)
            dark=max(0,min(80,int(settings.get('image_dark',8))))
            if dark:
                painter.fillRect(self.rect(),QColor(0,0,0,int(255*dark/100)))
        else:
            painter.fillRect(self.rect(),QColor('#eee5e5'))
        super().paintEvent(e)

    def _rescale_background(self):
        if self._bg_pixmap.isNull():
            self._bg_scaled=QPixmap()
            self.update()
            return
        target=QSize(max(1,self.width()),max(1,self.height()))
        self._bg_scaled=self._bg_pixmap.scaled(target,Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation)
        self.update()

    def update_background(self):
        raw=settings.get('image','')
        if not raw:
            self._bg_pixmap=QPixmap();self._bg_scaled=QPixmap();self.update();return
        try:
            pm=QPixmap()
            if pm.loadFromData(base64.b64decode(raw)):
                self._bg_pixmap=pm
                self._rescale_background()
            else:
                self._bg_pixmap=QPixmap();self._bg_scaled=QPixmap();self.update()
        except Exception:
            self._bg_pixmap=QPixmap();self._bg_scaled=QPixmap();self.update()

    def refresh_all(self):self.refresh_inventory();self.refresh_pencils();self.refresh_shop();self.refresh_lists();self.refresh_finance();self.update_header()
    def refresh_inventory(self):
        q=self.search.text().lower().strip();rows=[]
        for x in data['items']:
            s=' '.join(str(x.get(k,'')) for k in ['name','category','kind','color','room','cabinet','shelf','box','place','note']).lower()
            if q in s:rows.append(x)
        self.tree.setRowCount(len(rows))
        for r,x in enumerate(rows):
            vals=[x.get('name',''),x.get('category',''),x.get('kind',''),x.get('qty',0),x.get('unit',''),x.get('place','') or '—']
            for c,v in enumerate(vals):self.tree.setItem(r,c,QTableWidgetItem(str(v)))
        self.inv_count.setText(f'{len(data["items"])} készlettétel')
    def refresh_pencils(self):
        arr=data.get('pencils',[]);self.pt.setRowCount(len(arr))
        for r,x in enumerate(arr):
            for c,v in enumerate([x.get('name',''),x.get('sub',''),x.get('hardness',''),x.get('use',''),'⭐' if x.get('favorite') else '']):self.pt.setItem(r,c,QTableWidgetItem(str(v)))
        text=[]
        for x in arr:
            if x.get('favorite'):text.append(f"✏️ {x.get('name','')}\n{x.get('sub','')} | {x.get('hardness','')}\n{x.get('use','')}\n{x.get('note','')}\n")
        self.favp.setPlainText('\n'.join(text) if text else 'Még nincs bevált ceruza megjelölve.')
    def refresh_shop(self):
        self.shop.clear()
        for x in data.get('shopping',[]):self.shop.addItem(('☑ ' if x.get('done') else '☐ ')+x.get('name',''))
    def refresh_lists(self):
        for k in ['categories','types']:
            lb=getattr(self,'lb_'+k);lb.clear();lb.addItems(data[k])
    def refresh_finance(self):
        finance['paint_spend']=total_spend();save_all();sp=total_spend();sa=total_sales();self.spend_sum._value.setText(money(sp)+' Ft');self.sale_sum._value.setText(money(sa)+' Ft');self.diff_sum._value.setText(money(sa-sp)+' Ft')
        self.spends.setRowCount(len(finance['spends']))
        for r,x in enumerate(finance['spends']):
            for c,v in enumerate([x.get('date',''),money(x.get('amount',0))+' Ft',x.get('note','')]):self.spends.setItem(r,c,QTableWidgetItem(str(v)))
        self.sales.setRowCount(len(finance['sales']))
        for r,x in enumerate(finance['sales']):
            for c,v in enumerate([x.get('date',''),money(x.get('price',0))+' Ft',x.get('name','Festmény'),x.get('note','')]):self.sales.setItem(r,c,QTableWidgetItem(str(v)))
    def update_header(self):
        self.title.setText(settings.get('title',''));self.subtitle.setText(settings.get('subtitle',''));self.title.setVisible(bool(settings.get('title','')));self.subtitle.setVisible(bool(settings.get('subtitle','')))
    def rotate_message(self):self.footer.setText(random.choice(settings.get('messages',[])) if settings.get('messages') else '')

    def selected_index(self,table,source):
        r=table.currentRow();return r if 0<=r<len(source) else None
    def new_item(self):self.item_dialog()
    def edit_item(self):
        r=self.tree.currentRow()
        if r>=0:self.item_dialog(r)
    def item_dialog(self,index=None):
        old=data['items'][index] if index is not None else {};d=QDialog(self);d.setWindowTitle('Készlet szerkesztése' if index is not None else 'Új készlet');form=QFormLayout(d);fields={}
        for label,key in [('Megnevezés','name'),('Fajta','kind'),('Szín','color'),('Szoba','room'),('Szekrény / tároló','cabinet'),('Polc / fiók','shelf'),('Doboz / tároló','box'),('Megjegyzés','note')]:e=QLineEdit(str(old.get(key,'')));fields[key]=e;form.addRow(label,e)
        cat=QComboBox();cat.setEditable(True);cat.addItems(data['categories']);cat.setCurrentText(old.get('category',data['categories'][0]));fields['category']=cat;form.addRow('Kategória',cat)
        qty=QSpinBox();qty.setRange(0,999999);qty.setValue(int(old.get('qty',1)));fields['qty']=qty;form.addRow('Mennyiség',qty)
        unit=QComboBox();unit.addItems(['db','csomag','lap','ml','méter']);unit.setCurrentText(old.get('unit','db'));fields['unit']=unit;form.addRow('Egység',unit)
        fav=QCheckBox('⭐ Kedvenc');fav.setChecked(bool(old.get('favorite')));form.addRow('',fav)
        b=QPushButton('Mentés');b.setObjectName('accent');b.clicked.connect(lambda:self.commit_item(d,fields,fav,index));form.addRow('',b);d.exec()
    def commit_item(self,d,f,fav,index):
        name=f['name'].text().strip()
        if not name:return QMessageBox.warning(d,APP,'A megnevezés kötelező.')
        x={k:(v.currentText() if isinstance(v,QComboBox) else v.text().strip()) for k,v in f.items() if k not in ['qty','unit']};x['qty']=f['qty'].value();x['unit']=f['unit'].currentText();x['favorite']=fav.isChecked();x['place']=' → '.join(x[k] for k in ['room','cabinet','shelf','box'] if x[k])
        if index is None:data['items'].append(x)
        else:data['items'][index]=x
        save_all();d.accept();self.refresh_inventory()
    def delete_item(self):
        r=self.tree.currentRow();q=self.search.text().lower().strip();matches=[]
        for x in data['items']:
            s=' '.join(str(x.get(k,'')) for k in ['name','category','kind','color','room','cabinet','shelf','box','place','note']).lower()
            if q in s:matches.append(x)
        if 0<=r<len(matches) and QMessageBox.question(self,APP,'Biztosan törlöd ezt a tételt?')==QMessageBox.Yes:data['items'].remove(matches[r]);save_all();self.refresh_inventory()
    def change_qty(self,d):
        r=self.tree.currentRow();q=self.search.text().lower().strip();matches=[x for x in data['items'] if q in ' '.join(str(x.get(k,'')) for k in ['name','category','kind','color','room','cabinet','shelf','box','place','note']).lower()]
        if 0<=r<len(matches):matches[r]['qty']=max(0,int(matches[r].get('qty',0))+d);save_all();self.refresh_inventory()

    def pencil_dialog(self,index=None):
        arr=data.setdefault('pencils',[]);old=arr[index] if index is not None else {};d=QDialog(self);d.setWindowTitle('Ceruza');form=QFormLayout(d);n=QLineEdit(old.get('name',''));sub=QComboBox();sub.setEditable(True);sub.addItems(['Grafitceruza','Színes ceruza','Akvarellceruza','Mechanikus ceruza','Rajzceruza','Pasztellceruza','Egyéb']);sub.setCurrentText(old.get('sub','Grafitceruza'));hard=QLineEdit(old.get('hardness',''));use=QLineEdit(old.get('use',''));note=QLineEdit(old.get('note',''));fav=QCheckBox('⭐ Bevált / kedvenc');fav.setChecked(bool(old.get('favorite')))
        for lab,w in [('Ceruza neve',n),('Alkategória',sub),('Keménység',hard),('Mire használod?',use),('Megjegyzés',note)]:form.addRow(lab,w)
        form.addRow('',fav);b=QPushButton('Mentés');b.setObjectName('accent');b.clicked.connect(lambda:(self.commit_pencil(d,index,n,sub,hard,use,note,fav)));form.addRow('',b);d.exec()
    def commit_pencil(self,d,i,n,sub,hard,use,note,fav):
        if not n.text().strip():return QMessageBox.warning(d,APP,'A ceruza neve kötelező.')
        x={'name':n.text().strip(),'sub':sub.currentText(),'hardness':hard.text().strip(),'use':use.text().strip(),'note':note.text().strip(),'favorite':fav.isChecked()};arr=data.setdefault('pencils',[])
        if i is None: arr.append(x)
        else: arr[i]=x
        save_all();d.accept();self.refresh_pencils()
    def new_pencil(self):self.pencil_dialog()
    def edit_pencil(self):
        r=self.pt.currentRow()
        if r>=0:self.pencil_dialog(r)
    def delete_pencil(self):
        r=self.pt.currentRow()
        if r>=0 and QMessageBox.question(self,APP,'Törlöd ezt a ceruzát?')==QMessageBox.Yes:data['pencils'].pop(r);save_all();self.refresh_pencils()

    def add_shop(self):
        z=self.shop_entry.text().strip()
        if z:data.setdefault('shopping',[]).append({'name':z,'done':False});self.shop_entry.clear();save_all();self.refresh_shop()
    def toggle_shop(self):
        r=self.shop.currentRow()
        if r>=0:data['shopping'][r]['done']=not data['shopping'][r].get('done');save_all();self.refresh_shop()
    def delete_shop(self):
        r=self.shop.currentRow()
        if r>=0:data['shopping'].pop(r);save_all();self.refresh_shop()
    def add_list(self,k):
        e=getattr(self,'ent_'+k);z=e.text().strip()
        if z and z not in data[k]:data[k].append(z);e.clear();save_all();self.refresh_lists()
    def delete_list(self,k):
        lb=getattr(self,'lb_'+k);r=lb.currentRow()
        if r>=0:data[k].pop(r);save_all();self.refresh_lists()

    def add_spend(self):self.finance_dialog(False)
    def add_sale(self):self.finance_dialog(True)
    def finance_dialog(self,sale):
        d=QDialog(self);d.setWindowTitle('Eladott festmény' if sale else 'Festékre költött összeg');form=QFormLayout(d);name=QLineEdit();amount=QLineEdit();amount.setPlaceholderText('pl. 17000');date=QLineEdit(datetime.now().strftime('%Y.%m.%d'));note=QLineEdit();
        if sale:form.addRow('Festmény neve',name)
        form.addRow('Összeg (Ft)',amount);form.addRow('Dátum',date);form.addRow('Megjegyzés',note);b=QPushButton('Hozzáadás');b.setObjectName('accent');b.clicked.connect(lambda:self.commit_finance(d,sale,name,amount,date,note));form.addRow('',b);d.exec()
    def commit_finance(self,d,sale,name,amount,date,note):
        raw=amount.text().strip().replace(' ','').replace('.','').replace(',','.')
        try: val=float(raw) if raw else 0.0
        except ValueError: return QMessageBox.warning(d,APP,'Az összeghez csak számot írj, például: 17000')
        if sale:finance['sales'].append({'name':name.text().strip() or 'Festmény','price':val,'date':date.text().strip(),'note':note.text().strip()})
        else:finance['spends'].append({'amount':val,'date':date.text().strip(),'note':note.text().strip()})
        save_all();d.accept();self.refresh_finance()
    def delete_spend(self):
        r=self.spends.currentRow()
        if r>=0 and QMessageBox.question(self,APP,'Törlöd ezt a festékköltséget?')==QMessageBox.Yes:finance['spends'].pop(r);save_all();self.refresh_finance()
    def delete_sale(self):
        r=self.sales.currentRow()
        if r>=0 and QMessageBox.question(self,APP,'Törlöd ezt az eladást?')==QMessageBox.Yes:finance['sales'].pop(r);save_all();self.refresh_finance()

    def backup_quick(self):self.backup()
    def backup(self):
        fn,_=QFileDialog.getSaveFileName(self,'Biztonsági mentés','kreativ-keszlet-mentes.json','JSON (*.json)')
        if fn:
            with open(fn,'w',encoding='utf-8') as f:json.dump({'data':data,'settings':settings,'finance':finance},f,ensure_ascii=False,indent=2)
            QMessageBox.information(self,APP,'A biztonsági mentés elkészült.')
    def restore(self):
        fn,_=QFileDialog.getOpenFileName(self,'Biztonsági mentés visszaállítása','','JSON (*.json)')
        if not fn:return
        try:
            d=read_json(fn,{})
            if 'data' in d:data.clear();data.update(d['data'])
            if 'settings' in d:settings.clear();settings.update(d['settings'])
            if 'finance' in d:finance.clear();finance.update(d['finance'])
            save_all();self.apply_style();self.update_background();self.refresh_all();QMessageBox.information(self,APP,'A biztonsági mentést visszaállítottuk.')
        except Exception as e:QMessageBox.critical(self,APP,str(e))
    def export_inventory(self):
        fn,_=QFileDialog.getSaveFileName(self,'Készletlista mentése','kreativ-keszlet-lista.txt','Szövegfájl (*.txt)')
        if fn:
            with open(fn,'w',encoding='utf-8') as f:
                f.write('KREATÍV KÉSZLET\n\n');[f.write(f"{x.get('name','')} | {x.get('category','')} | {x.get('kind','')} | {x.get('qty',0)} {x.get('unit','db')} | {x.get('place','')}\n") for x in data['items']]
            QMessageBox.information(self,APP,'A készletlista elkészült.')

    def appearance(self):
        d=QDialog(self);d.setWindowTitle('🎨 Megjelenés szerkesztése');d.resize(700,600);form=QFormLayout(d)
        title=QLineEdit(settings.get('title',''));subtitle=QLineEdit(settings.get('subtitle',''));opacity=QSlider(Qt.Horizontal);opacity.setRange(10,60);opacity.setValue(int(settings.get('glass_opacity',28)));dark=QSlider(Qt.Horizontal);dark.setRange(0,45);dark.setValue(int(settings.get('image_dark',8)))
        for lab,w in [('Fejléc címe (üresen is menthető)',title),('Fejléc alcíme (üresen is menthető)',subtitle),('Felületek áttetszősége',opacity),('Háttér sötétítése',dark)]:form.addRow(lab,w)
        image_name=QLabel(settings.get('image_name','Nincs saját háttérkép'));form.addRow('Háttérkép',image_name);b=QPushButton('🖼️ Saját festmény kiválasztása');form.addRow('',b)
        def pick():
            fn,_=QFileDialog.getOpenFileName(d,'Saját festmény','','Képek (*.png *.jpg *.jpeg *.webp)')
            if fn:
                with open(fn,'rb') as f:settings['image']=base64.b64encode(f.read()).decode('ascii')
                settings['image_name']=os.path.basename(fn);image_name.setText(settings['image_name'])
        b.clicked.connect(pick)
        msg=QListWidget();msg.addItems(settings.get('messages',[]));form.addRow('Vicces üzenetek',msg);mr=QHBoxLayout();me=QLineEdit();me.setPlaceholderText('Új vicces üzenet');add=QPushButton('＋');rem=QPushButton('🗑');mr.addWidget(me,1);mr.addWidget(add);mr.addWidget(rem);form.addRow('',mr)
        add.clicked.connect(lambda:(msg.addItem(me.text().strip()) if me.text().strip() else None,me.clear()));rem.clicked.connect(lambda:msg.takeItem(msg.currentRow()) if msg.currentRow()>=0 else None)
        test=QPushButton('🌙 Esti kérdés kipróbálása');form.addRow('',test);save=QPushButton('✓ Mentés');save.setObjectName('accent');form.addRow('',save)
        test.clicked.connect(lambda:self.show_night(force=True));save.clicked.connect(lambda:self.save_appearance(d,title,subtitle,opacity,dark,msg));d.exec()
    def save_appearance(self,d,title,subtitle,opacity,dark,msg):
        settings['title']=title.text();settings['subtitle']=subtitle.text();settings['glass_opacity']=opacity.value();settings['image_dark']=dark.value();settings['messages']=[msg.item(i).text() for i in range(msg.count())];save_all();self.apply_style();self.update_background();self.update_header();self.rotate_message();d.accept()
    def check_updates_auto(self):
        self._check_updates(False)

    def check_updates_manual(self):
        self._check_updates(True)

    def _check_updates(self, manual=False):
        def worker():
            try:
                req=urllib.request.Request(f'https://api.github.com/repos/{UPDATE_REPO}/releases/latest',headers={'User-Agent':'KreativKeszlet-Updater','Accept':'application/vnd.github+json'})
                with urllib.request.urlopen(req,timeout=8,context=ssl.create_default_context(cafile=certifi.where())) as r: info=json.loads(r.read().decode('utf-8'))
                tag=info.get('tag_name','')
                asset=next((a for a in info.get('assets',[]) if a.get('name')=='KreativKeszlet-Windows.zip'),None)
                if update_is_newer(tag) and asset and asset.get('browser_download_url'):
                    self.update_signals.result.emit({'ok':True,'manual':manual,'tag':tag,'url':asset['browser_download_url']})
                elif manual:
                    self.update_signals.result.emit({'ok':True,'manual':True,'up_to_date':True,'tag':tag})
            except Exception as e:
                if manual:self.update_signals.result.emit({'ok':False,'manual':True,'error':str(e)})
        threading.Thread(target=worker,daemon=True).start()

    def handle_update_result(self, result):
        if not result.get('ok'):
            QMessageBox.warning(self,APP,'A frissítés ellenőrzése nem sikerült.\n\n'+result.get('error','Ismeretlen hiba')); return
        if result.get('up_to_date'):
            QMessageBox.information(self,APP,f'Nincs új verzió.\n\nJelenlegi verzió: {APP_VERSION}\nLegfrissebb: {result.get("tag","")}'); return
        tag=result.get('tag','')
        if QMessageBox.question(self,APP,f'🆕 Új verzió érhető el: {tag}\n\nJelenlegi verzió: {APP_VERSION}\n\nLetöltsem és telepítsem most?') != QMessageBox.Yes: return
        try:
            target_dir=os.path.dirname(os.path.abspath(sys.executable if getattr(sys,'frozen',False) else __file__))
            ps=download_and_prepare_update(result['url'],os.getpid(),target_dir)
            subprocess.Popen(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',ps],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            QMessageBox.information(self,APP,'A frissítés letöltése elkészült.\n\nA program most bezáródik, majd az új verzió automatikusan elindul.')
            self.close()
        except Exception as e:
            QMessageBox.critical(self,APP,'A frissítés nem sikerült.\n\n'+str(e))

    def show_night(self,force=False):
        q=QMessageBox(self);q.setWindowTitle('🌙 Zsófi');q.setText('🌙 Zsófi, elmentél már aludni?');q.setInformativeText('Ez az esti kérdés minden nap 23:00 után jelenik meg.');q.setStandardButtons(QMessageBox.Yes|QMessageBox.No);q.button(QMessageBox.Yes).setText('IGEN 😴');q.button(QMessageBox.No).setText('NEM 😅');r=q.exec();QMessageBox.information(self,'Zsófi','Ügyes vagy, Zsófi! Jó éjszakát! 🌙😴' if r==QMessageBox.Yes else 'Sejtettem... még egy kicsit alkotunk? 😂')
    def daily_check(self):
        now=datetime.now();key=now.strftime('%Y-%m-%d');state=read_json(DAILY,{'last':''})
        if now.hour>=23 and state.get('last')!=key:
            state['last']=key
            with open(DAILY,'w',encoding='utf-8') as f:json.dump(state,f)
            self.show_night()

app=QApplication(sys.argv);app.setStyle('Fusion');win=MainWindow();win.show();sys.exit(app.exec())
