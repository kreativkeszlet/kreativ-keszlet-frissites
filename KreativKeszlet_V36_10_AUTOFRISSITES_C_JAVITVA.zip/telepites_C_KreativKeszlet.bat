@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set "TARGET=C:\KreativKeszlet"
set "SOURCE=%~dp0dist\KreativKeszlet"
if not exist "%SOURCE%\KreativKeszlet.exe" (
  echo HIBA: A dist\KreativKeszlet\KreativKeszlet.exe nem talalhato.
  echo Eloszor futtasd a build_windows.bat fajlt.
  pause
  exit /b 1
)
if not exist "%TARGET%" mkdir "%TARGET%"
if errorlevel 1 (
  echo Nem sikerult letrehozni: %TARGET%
  echo Inditsd a BAT fajlt rendszergazdakent.
  pause
  exit /b 1
)
robocopy "%SOURCE%" "%TARGET%" /E /R:2 /W:1 >nul
if errorlevel 8 (
  echo A masolas nem sikerult.
  echo Ha a program mar fut, zarj be minden KreativKeszlet ablakot, majd probald ujra.
  pause
  exit /b 1
)
echo.
echo Telepites kesz: %TARGET%\KreativKeszlet.exe
echo A Vinted es egyeb adatok a Windows felhasznaloi mappajaban maradnak.
start "" "%TARGET%\KreativKeszlet.exe"
endlocal
