KREATIV KESZLET - V36

Ez a verzio a Windows program feluletet PySide6-ra epitette at, hogy a sajat festmeny teljes hatterkent latszodjon, es a programon beluli panelek tenylegesen uveges/atlatszo hatasuak legyenek.

A funkciok megmaradtak:
- keszlet, keres, szerkesztes, torles, mennyiseg
- ceruzak kulon alkategoriakkal es bevalt ceruzak
- bevasarlolista
- kategoriak es fajták
- festekkoltseg es festmeny-bevetel, kulon torlessel
- fejlec szoveg szerkesztese, akar teljesen uresre mentheto
- sajat festmeny hatter
- felulet attetszoseg allitasa
- vicces uzenetek
- esti 23:00 kerdes
- biztonsagi mentes/visszaallitas
- iPad webapp (a gepen futo helyi szerverrel)

TELEPITES / EXE:
1. Csomagold ki a ZIP-et.
2. Windows alatt futtasd a build_windows.bat fajlt.
3. A build a dist\KreativKeszlet\KreativKeszlet.exe fajlt kesziti el.
4. A korabbi adatok a felhasznaloi mappaban maradnak.

Fontos: az iPades resz tovabbra is a PC-n futo helyi szerverhez kapcsolodik ugyanazon a Wi-Fi-n.


V36 javitas: a sajat hatterkep most a QMainWindow sajat rajzolasaval jelenik meg, igy a kozponti feluletek alatt is latszik, es a Megjelenesben kivalasztott uj kep azonnal megjelenik.


V36: az iPad API cache-busttal es 5 masodperces automatikus frissitessel olvassa a PC kozponti adatait; a penzugyi adatok is az API valasz reszei.
