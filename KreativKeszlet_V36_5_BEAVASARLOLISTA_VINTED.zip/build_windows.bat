@echo off
cd /d "%~dp0"
chcp 65001 >nul
echo Kreativ Keszlet - modern, uveges felulet
 echo.
py -m pip install --upgrade PySide6 flask pillow pyinstaller certifi truststore
if errorlevel 1 (
  echo HIBA: a szukseges csomagok telepitese nem sikerult.
  pause
  exit /b 1
)
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
py -m PyInstaller --noconfirm --onedir --windowed --collect-all PySide6 --collect-all flask --collect-data certifi --collect-all truststore --add-data "ipad;ipad" --icon "kreativ_keszlet.ico" --name "KreativKeszlet" kreativ_keszlet_qt.py
if not exist "dist\KreativKeszlet\KreativKeszlet.exe" (
  echo HIBA: nem keszult el az EXE.
  pause
  exit /b 1
)
copy /Y "kreativ_keszlet.ico" "dist\KreativKeszlet\kreativ_keszlet.ico" >nul
echo.
echo KESZ!
echo Az uj program itt van:
echo dist\KreativKeszlet\KreativKeszlet.exe
echo.
pause
