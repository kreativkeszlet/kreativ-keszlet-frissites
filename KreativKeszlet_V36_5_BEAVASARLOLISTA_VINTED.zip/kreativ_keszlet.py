import tkinter as tk
from tkinter import ttk, messagebox, filedialog, colorchooser, simpledialog
import json, os, threading, webbrowser, base64, io, random, time
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from PIL import Image, ImageTk, ImageEnhance

APP="Kreatív Készlet"
BASE=getattr(__import__("sys"), "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
DATA=os.path.join(os.path.expanduser("~"),"KreativKeszlet_data.json")
SETTINGS=os.path.join(os.path.expanduser("~"),"KreativKeszlet_megjelenes.json")
FINANCE=os.path.join(os.path.expanduser("~"),"KreativKeszlet_penz.json")
WEB=os.path.join(BASE,"ipad")

DEFAULT={
 "categories":["Festék","Papír","Csomagolás","Eszközök","Dekoráció","Egyéb"],
 "types":["Akril","Tinta","Vízfesték","Tempera","Gouache","Olajfesték","Textilfesték","Üvegfesték","Egyéb"],
 "items":[],
 "pencils":[],
 "shopping":[]
}
DEFAULT_SETTINGS={
 "title":"Kreatív Készlet",
 "subtitle":"Minden kreatív kelléked egy helyen",
 "bg":"#f4efe8",
 "image":"",
 "image_name":"",
 "image_dark":12,
 "glass_opacity":35,
 "messages":[
  "Zsófi! Még mindig kupi van nálad? 😏",
  "Zsófi, megint vettél festéket? 😂",
  "A kupi nem kategória, Zsófi! 😜",
  "Mindennek van helye. Valahol. 🤔",
  "Zsófi, biztos tudod, melyik dobozban van?",
  "Még egy festék? Tényleg szükséged van rá? 😏",
  "Na, mit alkotunk ma? 🎨"
 ]
}
DEFAULT_FINANCE={"paint_spend":0.0,"sales":[]}

def read_json(path, default):
    try:
        with open(path,"r",encoding="utf-8") as f: return json.load(f)
    except Exception: return json.loads(json.dumps(default))

data=read_json(DATA,DEFAULT)
for k,v in DEFAULT.items():
    data.setdefault(k,list(v) if isinstance(v,list) else v)
settings=read_json(SETTINGS,DEFAULT_SETTINGS)
for k,v in DEFAULT_SETTINGS.items(): settings.setdefault(k,list(v) if isinstance(v,list) else v)
settings.setdefault("glass_opacity",48)
finance=read_json(FINANCE,DEFAULT_FINANCE)
finance.setdefault("paint_spend",0.0); finance.setdefault("sales",[])
lock=threading.RLock()

def save():
    with lock:
        tmp=DATA+".tmp"
        with open(tmp,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
        os.replace(tmp,DATA)

def save_settings():
    with open(SETTINGS,"w",encoding="utf-8") as f: json.dump(settings,f,ensure_ascii=False,indent=2)

def save_finance():
    with open(FINANCE,"w",encoding="utf-8") as f: json.dump(finance,f,ensure_ascii=False,indent=2)

# ---------------- iPad/local network ----------------
server=Flask(__name__,static_folder=WEB)
@server.get("/")
def home(): return send_from_directory(WEB,"index.html")
@server.get("/api/data")
def api_get():
    with lock: return jsonify(data)
@server.post("/api/data")
def api_put():
    incoming=request.get_json(force=True)
    if not isinstance(incoming,dict) or "items" not in incoming: return jsonify(error="invalid"),400
    with lock:
        data.update(incoming); data.setdefault("pencils",[]); data.setdefault("shopping",[]); save()
    return jsonify(ok=True)
@server.get("/<path:p>")
def static_files(p): return send_from_directory(WEB,p)
def run_server(): server.run(host="0.0.0.0",port=8765,debug=False,use_reloader=False)

# ---------------- UI helpers ----------------
# Tkinter widgetenkénti valódi alpha nem támogatott, ezért az áttetszőséget
# színkeveréssel/üveges hatással szimuláljuk.
def blend_hex(a,b,t):
    t=max(0.0,min(1.0,float(t)))
    a=a.lstrip("#"); b=b.lstrip("#")
    vals=[]
    for i in (0,2,4):
        x=int(a[i:i+2],16); y=int(b[i:i+2],16)
        vals.append(round(x*(1-t)+y*t))
    return "#%02x%02x%02x"%tuple(vals)

root=tk.Tk()
_icon_path=os.path.join(BASE,"kreativ_keszlet.ico")
try: root.iconbitmap(_icon_path)
except: pass
root.title(settings.get("title") or APP)
root.geometry("1180x760"); root.minsize(950,620)

BG="#e8dfe0"; CARD="#f4ecee"; INK="#351b20"; MUTED="#705b60"; ACCENT="#c93642"; ACCENT2="#e45b65"
# Az áttetszőség most ténylegesen hat a program felületeire is: alacsonyabb érték = jobban érvényesülő festmény.
_GLASS_BASE="#fbf6f5"; _GLASS2_BASE="#f3e7e8"
def glass_colors():
    op=max(15,min(70,int(settings.get("glass_opacity",42))))
    # Világos, üveges hatású felületek pirosas árnyalattal.
    # Alacsonyabb értéknél jobban érvényesül a háttérfestmény.
    t=op/100.0
    g=blend_hex("#ead3d5", _GLASS_BASE, t)
    g2=blend_hex("#e5c9cc", _GLASS2_BASE, t)
    return g,g2
GLASS,GLASS2=glass_colors()
style=ttk.Style()
try: style.theme_use("clam")
except: pass
style.configure("TNotebook",background=GLASS,borderwidth=0,tabmargins=(4,4,4,0))
style.configure("TNotebook.Tab",padding=(17,10),font=("Segoe UI",10,"bold"),background=GLASS2,foreground=INK)
style.map("TNotebook.Tab",background=[("selected", "#fff7f7"), ("active", "#f7e4e5")],foreground=[("selected", ACCENT)])
style.configure("Treeview",rowheight=36,font=("Segoe UI",10),background=GLASS2,fieldbackground=GLASS2,foreground=INK,borderwidth=0,relief="flat")
style.map("Treeview",background=[("selected",ACCENT)],foreground=[("selected","white")])
style.configure("Treeview.Heading",font=("Segoe UI",10,"bold"),padding=(8,10),background="#eadadd",foreground=INK,relief="flat")
style.configure("TButton",font=("Segoe UI",10,"bold"),padding=(11,7),relief="flat")
style.configure("Accent.TButton",background=ACCENT,foreground="white",font=("Segoe UI",10,"bold"),padding=(12,8))
style.map("Accent.TButton",background=[("active",ACCENT2)])
style.configure("TLabel",font=("Segoe UI",10),foreground=INK)
style.configure("Glass.TFrame",background=GLASS)
style.configure("Glass2.TFrame",background=GLASS2)
style.configure("TCheckbutton",font=("Segoe UI",10),foreground=INK)
style.configure("TCheckbutton",font=("Segoe UI",10),foreground=INK)

# Full-window painting background
# The image is deliberately cached: rebuilding a large PIL image on every
# <Configure> event made the previous version unnecessarily slow.
bg_label=None; bg_photo=None; bg_cache_key=None; bg_source_pil=None
bg_refresh_pending=False
def make_bg_photo():
    global bg_photo, bg_cache_key, bg_source_pil
    raw=settings.get("image","")
    if not raw: return None
    w=max(root.winfo_width(),950); h=max(root.winfo_height(),620)
    dark=int(settings.get("image_dark",12))
    key=(len(raw),hash(raw),w,h,dark)
    if key==bg_cache_key and bg_photo is not None:
        return bg_photo
    try:
        if bg_source_pil is None or bg_source_pil[0] != hash(raw):
            pil=Image.open(io.BytesIO(base64.b64decode(raw))).convert("RGB")
            bg_source_pil=(hash(raw),pil.copy())
        else:
            pil=bg_source_pil[1].copy()
        pil=ImageEnhance.Brightness(pil).enhance(max(.45,1-dark/100))
        ratio=max(w/pil.width,h/pil.height)
        nw,nh=int(pil.width*ratio),int(pil.height*ratio)
        if (nw,nh)!=(pil.width,pil.height):
            pil=pil.resize((nw,nh),Image.LANCZOS)
        left=max(0,(pil.width-w)//2); top=max(0,(pil.height-h)//2)
        pil=pil.crop((left,top,left+w,top+h))
        bg_photo=ImageTk.PhotoImage(pil); bg_cache_key=key
        return bg_photo
    except Exception:
        return None

def refresh_background(_event=None):
    global bg_label,bg_photo,bg_cache_key,bg_refresh_pending
    bg_refresh_pending=False
    ph=make_bg_photo()
    if ph:
        if bg_label is None:
            bg_label=tk.Label(root,image=ph,bd=0,highlightthickness=0)
            bg_label.place(x=0,y=0,relwidth=1,relheight=1)
        else: bg_label.configure(image=ph)
        bg_label.lower()
    else:
        if bg_label: bg_label.place_forget()
        root.configure(bg=settings.get("bg",BG))

def schedule_background_refresh(_event=None):
    global bg_refresh_pending
    if not bg_refresh_pending:
        bg_refresh_pending=True
        root.after_idle(refresh_background)
root.bind("<Configure>",schedule_background_refresh)

# translucent-looking white cards with a little transparency effect via soft warm background
main=tk.Frame(root,bg=GLASS,bd=0)
main.place(relx=.5,rely=.5,relwidth=.96,relheight=.94,anchor="center")
# Tkinter doesn't support alpha per widget; use warm cards that leave painting visible around them.
header=tk.Frame(main,bg=GLASS,height=86,highlightthickness=1,highlightbackground="#ffffff")
header.pack(fill="x",padx=12,pady=(12,6)); header.pack_propagate(False)

# Fejléc – visszahozva a címet és az alcímet.
header_text=tk.Frame(header,bg=GLASS)
header_text.pack(side="left",fill="both",expand=True,padx=20,pady=11)
header_title=tk.Label(header_text,text=settings.get("title") or APP,font=("Segoe UI",22,"bold"),bg=GLASS,fg=INK,anchor="w")
header_title.pack(anchor="w")
header_subtitle=tk.Label(header_text,text=settings.get("subtitle") or "Minden kreatív kelléked egy helyen",font=("Segoe UI",10),bg=GLASS,fg=MUTED,anchor="w")
header_subtitle.pack(anchor="w")

btns=tk.Frame(header,bg=GLASS); btns.pack(side="right",padx=15)
tk.Button(btns,text="🎨 Megjelenés",command=lambda:appearance_editor(),bg=ACCENT,fg="white",relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=8).pack(side="left",padx=4)
tk.Button(btns,text="💾 Mentés",command=save, bg="#f7e7e8",fg=INK,relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=8).pack(side="left",padx=4)
tk.Button(btns,text="＋ Új készlet",command=lambda:editor(),bg="#f7e7e8",fg=INK,relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=8).pack(side="left",padx=4)

nb=ttk.Notebook(main); nb.pack(fill="both",expand=True,padx=12,pady=(0,12))
# Daily playful message footer
message_footer=tk.Label(main,text="",font=("Segoe UI",10,"italic"),bg=GLASS,fg=INK,pady=7)
message_footer.pack(fill="x",padx=18,pady=(0,5))

def rotate_message():
    msgs=settings.get("messages",[])
    message_footer.config(text=random.choice(msgs) if msgs else "")
    root.after(25000,rotate_message)

tab=ttk.Frame(nb,padding=12); nb.add(tab,text="📦 Készlet")
search=tk.StringVar()
sf=ttk.Frame(tab); sf.pack(fill="x",pady=(0,10))
ttk.Label(sf,text="🔎 Keresés").pack(side="left")
ttk.Entry(sf,textvariable=search).pack(side="left",fill="x",expand=True,padx=8)
ttk.Button(sf,text="Keresés törlése",command=lambda:search.set("")).pack(side="left")
cols=("name","category","kind","qty","unit","place")
tree=ttk.Treeview(tab,columns=cols,show="headings")
heads={"name":"Megnevezés","category":"Kategória","kind":"Fajta","qty":"Mennyiség","unit":"Egység","place":"Hely"}
for c in cols: tree.heading(c,text=heads[c]);tree.column(c,width=125)
tree.column("name",width=220);tree.column("place",width=360)
tree.pack(fill="both",expand=True)
bf=ttk.Frame(tab);bf.pack(fill="x",pady=8)
ttk.Button(bf,text="Szerkesztés",command=lambda:edit_selected()).pack(side="left")
ttk.Button(bf,text="Törlés",command=lambda:delete_selected()).pack(side="left",padx=6)
ttk.Button(bf,text="−1 mennyiség",command=lambda:change_qty(-1)).pack(side="left")
ttk.Button(bf,text="+1 mennyiség",command=lambda:change_qty(1)).pack(side="left",padx=6)
count_label=ttk.Label(bf,text="");count_label.pack(side="right")

def refresh():
    for x in tree.get_children(): tree.delete(x)
    q=search.get().lower().strip()
    for i,x in enumerate(data["items"]):
        s=" ".join(str(x.get(k,"")) for k in ["name","category","kind","color","room","cabinet","shelf","box","place","note"]).lower()
        if q in s:
            tree.insert("", "end", iid=str(i), values=(x.get("name",""),x.get("category",""),x.get("kind",""),x.get("qty",0),x.get("unit",""),x.get("place","") or "—"))
    count_label.config(text=f"{len(data['items'])} készlettétel")
    refresh_dashboard()
search.trace_add("write",lambda *_:refresh())

def selected_index():
    s=tree.selection()
    return int(s[0]) if s else None
def edit_selected():
    i=selected_index()
    if i is not None: editor(i)
def delete_selected():
    i=selected_index()
    if i is not None and messagebox.askyesno(APP,"Biztosan törlöd ezt a tételt?"):
        data["items"].pop(i);save();refresh()
def change_qty(delta):
    i=selected_index()
    if i is not None:
        data["items"][i]["qty"]=max(0,int(data["items"][i].get("qty",0))+delta);save();refresh()

def editor(index=None):
    w=tk.Toplevel(root); w.title("Készlet szerkesztése" if index is not None else "Új készlet"); w.geometry("650x700"); w.transient(root); w.grab_set()
    f=ttk.Frame(w,padding=18);f.pack(fill="both",expand=True)
    old=data["items"][index] if index is not None else {}; v={}
    def fld(label,key,default=""):
        ttk.Label(f,text=label).pack(anchor="w",pady=(6,1))
        v[key]=tk.StringVar(value=str(old.get(key,default)))
        ttk.Entry(f,textvariable=v[key]).pack(fill="x")
    fld("Megnevezés","name")
    ttk.Label(f,text="Kategória").pack(anchor="w",pady=(7,1));v["category"]=tk.StringVar(value=old.get("category",data["categories"][0]))
    ttk.Combobox(f,textvariable=v["category"],values=data["categories"]).pack(fill="x")
    fld("Fajta","kind")
    row=ttk.Frame(f);row.pack(fill="x")
    a=ttk.Frame(row);a.pack(side="left",fill="x",expand=True,padx=(0,5));ttk.Label(a,text="Mennyiség").pack(anchor="w")
    v["qty"]=tk.StringVar(value=str(old.get("qty",1)));ttk.Entry(a,textvariable=v["qty"]).pack(fill="x")
    b=ttk.Frame(row);b.pack(side="left",fill="x",expand=True,padx=(5,0));ttk.Label(b,text="Egység").pack(anchor="w")
    v["unit"]=tk.StringVar(value=old.get("unit","db"));ttk.Combobox(b,textvariable=v["unit"],values=["db","csomag","lap","ml","méter"]).pack(fill="x")
    fld("Szín (opcionális)","color")
    fav=tk.BooleanVar(value=bool(old.get("favorite",False)))
    ttk.Checkbutton(f,text="⭐ Kedvenc készlettétel",variable=fav).pack(anchor="w",pady=6)
    ttk.Label(f,text="📍 Tárolási hely",font=("Segoe UI",11,"bold")).pack(anchor="w",pady=(12,0))
    fld("Szoba","room");fld("Szekrény / tároló","cabinet");fld("Polc / fiók","shelf");fld("Doboz / tároló","box");fld("Megjegyzés","note")
    def commit():
        if not v["name"].get().strip(): return messagebox.showwarning(APP,"A megnevezés kötelező.",parent=w)
        try:q=max(0,int(v["qty"].get()))
        except:q=0
        x={k:z.get().strip() for k,z in v.items() if k not in ("qty","unit")}
        x["qty"]=q;x["unit"]=v["unit"].get();x["favorite"]=fav.get()
        x["place"]=" → ".join(x[k] for k in ("room","cabinet","shelf","box") if x[k])
        x["id"]=data["items"][index].get("id",index) if index is not None else time.time_ns()
        if index is None:data["items"].append(x)
        else:data["items"][index]=x
        save();refresh();w.destroy()
    ttk.Button(f,text="Mentés",style="Accent.TButton",command=commit).pack(pady=14)

# Dashboard / áttekintés

dt=ttk.Frame(nb,padding=18); nb.insert(0,dt,text="🏠 Áttekintés")
tk.Label if False else None

ttk.Label(dt,text="🏠 Kreatív Készlet – áttekintés",font=("Segoe UI",18,"bold")).pack(anchor="w")
summary=tk.Frame(dt,bg="#eee7f2"); summary.pack(fill="x",pady=12)
stats=[]
for _ in range(4):
    l=tk.Label(summary,text="",font=("Segoe UI",14,"bold"),bg="#eee7f2",fg=INK); l.pack(side="left",expand=True,padx=10,pady=18); stats.append(l)
low_frame=ttk.Frame(dt); low_frame.pack(fill="both",expand=True)
ttk.Label(low_frame,text="⚠️ Kevés készlet (2 vagy kevesebb)",font=("Segoe UI",12,"bold")).pack(anchor="w")
low_list=tk.Listbox(low_frame,height=8,font=("Segoe UI",10)); low_list.pack(fill="both",expand=True,pady=8)

def refresh_dashboard():
    total=len(data.get("items",[])); cats=len(data.get("categories",[])); low=[x for x in data.get("items",[]) if int(x.get("qty",0) or 0)<=2]
    fav=sum(1 for x in data.get("items",[]) if x.get("favorite"))
    stats[0].config(text=f"📦 {total} tétel"); stats[1].config(text=f"🗂️ {cats} kategória"); stats[2].config(text=f"⚠️ {len(low)} kevés"); stats[3].config(text=f"⭐ {fav} kedvenc")
    low_list.delete(0,"end")
    for x in low: low_list.insert("end",f"{x.get('name','')} – {x.get('qty',0)} {x.get('unit','db')}")

# Pencil section
pt=ttk.Frame(nb,padding=15); nb.add(pt,text="✏️ Ceruzák")
ttk.Label(pt,text="✏️ Ceruzák",font=("Segoe UI",18,"bold")).pack(anchor="w")
ttk.Label(pt,text="Külön nyilvántartás a ceruzáknak és annak, melyik vált be.",foreground=MUTED).pack(anchor="w",pady=(2,12))
prows=ttk.Frame(pt); prows.pack(fill="both",expand=True)
pl=ttk.Frame(prows); pl.pack(side="left",fill="both",expand=True,padx=(0,8))
pr=ttk.Frame(prows); pr.pack(side="right",fill="both",expand=True,padx=(8,0))
ttk.Label(pl,text="Ceruzák",font=("Segoe UI",12,"bold")).pack(anchor="w")
pencil_tree=ttk.Treeview(pl,columns=("name","sub","hard","use","fav"),show="headings")
for c,h in [("name","Ceruza"),("sub","Alkategória"),("hard","Keménység"),("use","Használat"),("fav","Bevált")]: pencil_tree.heading(c,text=h); pencil_tree.column(c,width=110)
pencil_tree.pack(fill="both",expand=True,pady=7)

def refresh_pencils():
    for x in pencil_tree.get_children(): pencil_tree.delete(x)
    for i,x in enumerate(data.get("pencils",[])):
        pencil_tree.insert("","end",iid=str(i),values=(x.get("name",""),x.get("sub",""),x.get("hardness",""),x.get("use",""),"⭐" if x.get("favorite") else ""))

def pencil_editor(index=None):
    w=tk.Toplevel(root); w.title("Ceruza szerkesztése" if index is not None else "Új ceruza"); w.geometry("500x520"); f=ttk.Frame(w,padding=18); f.pack(fill="both",expand=True)
    old=data.get("pencils",[])[index] if index is not None else {}
    vars={}
    def fld(label,key):
        ttk.Label(f,text=label).pack(anchor="w",pady=(7,1)); vars[key]=tk.StringVar(value=str(old.get(key,""))); ttk.Entry(f,textvariable=vars[key]).pack(fill="x")
    fld("Ceruza neve","name")
    ttk.Label(f,text="Alkategória").pack(anchor="w",pady=(7,1)); vars["sub"]=tk.StringVar(value=old.get("sub","Grafitceruza")); ttk.Combobox(f,textvariable=vars["sub"],values=["Grafitceruza","Színes ceruza","Akvarellceruza","Mechanikus ceruza","Rajzceruza","Pasztellceruza","Egyéb"]).pack(fill="x")
    fld("Keménység (pl. HB, 2B, 4B)","hardness"); fld("Mire használod?","use"); fld("Megjegyzés (pl. jó minőségű, nem törik)","note")
    fav=tk.BooleanVar(value=bool(old.get("favorite",False))); ttk.Checkbutton(f,text="⭐ Bevált / kedvenc ceruza",variable=fav).pack(anchor="w",pady=12)
    def ok():
        x={k:v.get().strip() for k,v in vars.items()}; x["favorite"]=fav.get()
        if not x["name"]: return messagebox.showwarning(APP,"A ceruza neve kötelező.",parent=w)
        if index is None: data.setdefault("pencils",[]).append(x)
        else: data["pencils"][index]=x
        save(); refresh_pencils(); refresh_dashboard(); w.destroy()
    ttk.Button(f,text="Mentés",style="Accent.TButton",command=ok).pack(pady=10)

def edit_pencil():
    s=pencil_tree.selection();
    if s: pencil_editor(int(s[0]))
def del_pencil():
    s=pencil_tree.selection()
    if s and messagebox.askyesno(APP,"Törlöd ezt a ceruzát?"):
        data["pencils"].pop(int(s[0])); save(); refresh_pencils(); refresh_dashboard()

pb=ttk.Frame(pl); pb.pack(fill="x",pady=6); ttk.Button(pb,text="＋ Új ceruza",command=pencil_editor).pack(side="left"); ttk.Button(pb,text="Szerkesztés",command=edit_pencil).pack(side="left",padx=5); ttk.Button(pb,text="Törlés",command=del_pencil).pack(side="left")
ttk.Label(pr,text="⭐ Bevált / kedvenc ceruzák",font=("Segoe UI",12,"bold")).pack(anchor="w")
fav_text=tk.Text(pr,height=15,wrap="word",font=("Segoe UI",10)); fav_text.pack(fill="both",expand=True,pady=7)
def refresh_fav_pencils():
    fav_text.config(state="normal"); fav_text.delete("1.0","end")
    favs=[x for x in data.get("pencils",[]) if x.get("favorite")]
    if not favs: fav_text.insert("end","Még nincs bevált ceruza megjelölve.")
    for x in favs:
        fav_text.insert("end",f"✏️ {x.get('name','')}\n  {x.get('sub','')} | {x.get('hardness','')}\n  {x.get('use','')}\n  {x.get('note','')}\n\n")
    fav_text.config(state="disabled")

# Shopping list
st=ttk.Frame(nb,padding=18); nb.add(st,text="🛒 Bevásárlólista")
ttk.Label(st,text="🛒 Bevásárlólista",font=("Segoe UI",18,"bold")).pack(anchor="w")
shop_entry=tk.StringVar(); ttk.Entry(st,textvariable=shop_entry).pack(fill="x",pady=8)
shop_lb=tk.Listbox(st,font=("Segoe UI",11)); shop_lb.pack(fill="both",expand=True)
def refresh_shop():
    shop_lb.delete(0,"end")
    for x in data.get("shopping",[]): shop_lb.insert("end",("☐ " if not x.get("done") else "☑ ")+x.get("name",""))
def add_shop():
    z=shop_entry.get().strip()
    if z: data.setdefault("shopping",[]).append({"name":z,"done":False}); shop_entry.set(""); save(); refresh_shop()
def toggle_shop():
    s=shop_lb.curselection()
    if s: data["shopping"][s[0]]["done"]=not data["shopping"][s[0]].get("done"); save(); refresh_shop()
def del_shop():
    s=shop_lb.curselection()
    if s: data["shopping"].pop(s[0]); save(); refresh_shop()
shb=ttk.Frame(st); shb.pack(fill="x",pady=7); ttk.Button(shb,text="＋ Hozzáadás",command=add_shop).pack(side="left"); ttk.Button(shb,text="☑ Megvettem",command=toggle_shop).pack(side="left",padx=6); ttk.Button(shb,text="Törlés",command=del_shop).pack(side="left")

# Categories and types
for key,title in [("categories","Kategóriák"),("types","Fajták")]:
    t=ttk.Frame(nb,padding=15);nb.add(t,text=title)
    ttk.Label(t,text=title,font=("Segoe UI",18,"bold")).pack(anchor="w")
    lb=tk.Listbox(t,height=16,font=("Segoe UI",11));lb.pack(fill="x",pady=10)
    ent=ttk.Entry(t);ent.pack(fill="x")
    def make_funcs(k,box,e):
        def ref(): box.delete(0,"end"); [box.insert("end",z) for z in data[k]]
        def add():
            z=e.get().strip()
            if z and z not in data[k]:data[k].append(z);save();e.delete(0,"end");ref()
        def rem():
            s=box.curselection()
            if s:data[k].pop(s[0]);save();ref()
        return ref,add,rem
    ref,add,rem=make_funcs(key,lb,ent)
    ttk.Button(t,text="＋ Hozzáadás",command=add).pack(side="left");ttk.Button(t,text="Törlés",command=rem).pack(side="left",padx=6);ref()

# Finance tab - paint only, kártyás/üveges elrendezés
ft=tk.Frame(nb,bg=GLASS,highlightthickness=0)
nb.add(ft,text="💰 Festék / bevétel")

# Régi verzióból átvett egyetlen összeg átalakítása külön tétellé.
finance.setdefault("spends",[])
if not finance["spends"] and float(finance.get("paint_spend",0) or 0) != 0:
    finance["spends"].append({"amount":float(finance.get("paint_spend",0)),"date":"Korábbi adat","note":""})

def parse_money(value):
    z=str(value).strip().replace("Ft","").replace(" ","")
    if not z:return None
    if "," in z:z=z.replace(".","").replace(",", ".")
    else:z=z.replace(".","")
    return float(z)

def total_spend():
    return sum(float(x.get("amount",0) or 0) for x in finance.get("spends",[]))

def finance_bg():
    return glass_colors()[0]

def make_card(parent, title, subtitle=None):
    card=tk.Frame(parent,bg=finance_bg(),highlightthickness=1,highlightbackground="#ffffff",bd=0)
    head=tk.Frame(card,bg=finance_bg());head.pack(fill="x",padx=16,pady=(12,7))
    tk.Label(head,text=title,font=("Segoe UI",13,"bold"),bg=finance_bg(),fg=INK).pack(side="left")
    if subtitle:
        tk.Label(card,text=subtitle,font=("Segoe UI",9),bg=finance_bg(),fg=MUTED,anchor="w").pack(fill="x",padx=14,pady=(0,7))
    return card

def refresh_finance():
    spend=total_spend()
    rev=sum(float(s.get("price",0) or 0) for s in finance.get("sales",[]))
    diff=rev-spend
    spend_lbl.config(text=f"🎨 Festékre: {spend:,.0f} Ft".replace(","," "))
    rev_lbl.config(text=f"💰 Bevétel: {rev:,.0f} Ft".replace(","," "))
    profit_lbl.config(text=("📈 Különbség: " if diff>=0 else "📉 Különbség: ")+f"{diff:,.0f} Ft".replace(","," "))
    for tree in (spend_tree,sales_tree):
        for x in tree.get_children(): tree.delete(x)
    for i,x in enumerate(finance.get("spends",[])):
        spend_tree.insert("","end",iid=str(i),values=(x.get("date",""),f"{float(x.get('amount',0)):,.0f} Ft".replace(","," "),x.get("note","")))
    for i,s in enumerate(finance.get("sales",[])):
        sales_tree.insert("","end",iid=str(i),values=(s.get("date",""),f"{float(s.get('price',0)):,.0f} Ft".replace(","," "),s.get("name","Festmény"),s.get("note","")))

def add_spend():
    w=tk.Toplevel(root);w.title("Festékre költött összeg");w.geometry("430x300");w.resizable(False,False)
    f=ttk.Frame(w,padding=18);f.pack(fill="both",expand=True)
    ttk.Label(f,text="Összeg (Ft)",font=("Segoe UI",10,"bold")).pack(anchor="w")
    amount=tk.StringVar();e=ttk.Entry(f,textvariable=amount);e.pack(fill="x",pady=(4,10));e.focus_set()
    ttk.Label(f,text="Megjegyzés (opcionális)").pack(anchor="w")
    note=tk.StringVar();ttk.Entry(f,textvariable=note).pack(fill="x",pady=(4,10))
    ttk.Label(f,text="Dátum").pack(anchor="w")
    date=tk.StringVar(value=datetime.now().strftime("%Y.%m.%d"));ttk.Entry(f,textvariable=date).pack(fill="x",pady=(4,14))
    def ok():
        try:p=parse_money(amount.get())
        except:p=None
        if p is None or p<0:return messagebox.showwarning(APP,"Kérlek, helyes összeget írj be. Például: 17000 vagy 17 000",parent=w)
        finance.setdefault("spends",[]).append({"amount":p,"date":date.get().strip(),"note":note.get().strip()})
        finance["paint_spend"]=total_spend();save_finance();refresh_finance();w.destroy()
    row=ttk.Frame(f);row.pack(fill="x")
    ttk.Button(row,text="Hozzáadás",style="Accent.TButton",command=ok).pack(side="left")
    ttk.Button(row,text="Mégse",command=w.destroy).pack(side="left",padx=8)

def delete_spend():
    sel=spend_tree.selection()
    if not sel:return
    idx=int(sel[0]); item=finance.get("spends",[])[idx]
    if messagebox.askyesno(APP,f"Törlöd ezt a festékköltséget?\n{float(item.get('amount',0)):,.0f} Ft".replace(","," "),parent=root):
        finance["spends"].pop(idx);finance["paint_spend"]=total_spend();save_finance();refresh_finance()

def add_sale():
    w=tk.Toplevel(root);w.title("Festmény eladása");w.geometry("430x320");w.resizable(False,False)
    f=ttk.Frame(w,padding=18);f.pack(fill="both",expand=True)
    ttk.Label(f,text="Festmény neve (opcionális)").pack(anchor="w");name=tk.StringVar();ttk.Entry(f,textvariable=name).pack(fill="x",pady=(4,10))
    ttk.Label(f,text="Eladási ár (Ft)").pack(anchor="w");price=tk.StringVar();ttk.Entry(f,textvariable=price).pack(fill="x",pady=(4,10))
    ttk.Label(f,text="Dátum").pack(anchor="w");date=tk.StringVar(value=datetime.now().strftime("%Y.%m.%d"));ttk.Entry(f,textvariable=date).pack(fill="x",pady=(4,14))
    def ok():
        try:p=parse_money(price.get())
        except:p=None
        if p is None or p<0:return messagebox.showwarning(APP,"Az eladási ár legyen helyes szám.",parent=w)
        finance.setdefault("sales",[]).append({"name":name.get().strip() or "Festmény","price":p,"date":date.get().strip()})
        save_finance();refresh_finance();w.destroy()
    row=ttk.Frame(f);row.pack(fill="x")
    ttk.Button(row,text="Hozzáadás",style="Accent.TButton",command=ok).pack(side="left")
    ttk.Button(row,text="Mégse",command=w.destroy).pack(side="left",padx=8)

def delete_sale():
    sel=sales_tree.selection()
    if not sel:return
    idx=int(sel[0])
    if messagebox.askyesno(APP,"Törlöd ezt az eladást?",parent=root):
        finance["sales"].pop(idx);save_finance();refresh_finance()

# Cím és összefoglaló kártyák
intro=tk.Frame(ft,bg=GLASS);intro.pack(fill="x",padx=18,pady=(14,8))
tk.Label(intro,text="💰 Festék költsége és festmények bevétele",font=("Segoe UI",18,"bold"),bg=GLASS,fg=INK).pack(anchor="w")
tk.Label(intro,text="A festékekre költött összegeket és a festmények eladásait külön vezetheted.",font=("Segoe UI",10),bg=GLASS,fg=MUTED).pack(anchor="w",pady=(3,0))

summary=tk.Frame(ft,bg=GLASS);summary.pack(fill="x",padx=18,pady=5)
for col in range(3): summary.grid_columnconfigure(col,weight=1)
def summary_card(col):
    f=tk.Frame(summary,bg=finance_bg(),highlightthickness=1,highlightbackground="#ffffff")
    f.grid(row=0,column=col,sticky="nsew",padx=5)
    return f
c1=summary_card(0);c2=summary_card(1);c3=summary_card(2)
spend_lbl=tk.Label(c1,text="",font=("Segoe UI",16,"bold"),bg="#f2e9ed",fg=INK);spend_lbl.pack(padx=18,pady=18)
rev_lbl=tk.Label(c2,text="",font=("Segoe UI",16,"bold"),bg="#f2e9ed",fg=INK);rev_lbl.pack(padx=18,pady=18)
profit_lbl=tk.Label(c3,text="",font=("Segoe UI",16,"bold"),bg="#f2e9ed",fg=INK);profit_lbl.pack(padx=18,pady=18)

content=tk.Frame(ft,bg=GLASS);content.pack(fill="both",expand=True,padx=18,pady=8)
content.grid_columnconfigure(0,weight=1);content.grid_columnconfigure(1,weight=1);content.grid_rowconfigure(0,weight=1);content.grid_rowconfigure(1,weight=0)

left=make_card(content,"🎨 Festékre költött összegek","Kijelölhetsz egy tételt, majd törölheted.")
left.grid(row=0,column=0,sticky="nsew",padx=(0,5),pady=(0,8))
left_btn=tk.Frame(left,bg=finance_bg());left_btn.pack(fill="x",padx=12,pady=(0,7))
tk.Button(left_btn,text="＋ Hozzáadás",command=add_spend,bg=ACCENT,fg="white",relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=7).pack(side="left")
tk.Button(left_btn,text="🗑 Törlés",command=delete_spend,bg="#f0dfe1",fg=INK,relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=7).pack(side="left",padx=6)
spend_tree=ttk.Treeview(left,columns=("date","amount","note"),show="headings",height=7)
for c,h,w in [("date","Dátum",100),("amount","Összeg",115),("note","Megjegyzés",180)]:spend_tree.heading(c,text=h);spend_tree.column(c,width=w)
spend_tree.pack(fill="both",expand=True,padx=12,pady=(0,12))

right=make_card(content,"💰 Eladott festmények bevétele","Az eladások külön nyilvántarthatók és törölhetők.")
right.grid(row=0,column=1,sticky="nsew",padx=(5,0),pady=(0,8))
right_btn=tk.Frame(right,bg=finance_bg());right_btn.pack(fill="x",padx=12,pady=(0,7))
tk.Button(right_btn,text="＋ Hozzáadás",command=add_sale,bg=ACCENT,fg="white",relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=7).pack(side="left")
tk.Button(right_btn,text="🗑 Törlés",command=delete_sale,bg="#f0dfe1",fg=INK,relief="flat",bd=0,font=("Segoe UI",10,"bold"),padx=12,pady=7).pack(side="left",padx=6)
sales_tree=ttk.Treeview(right,columns=("date","price","name","note"),show="headings",height=7)
for c,h,w in [("date","Dátum",100),("price","Összeg",115),("name","Festmény",170),("note","Megjegyzés",150)]:sales_tree.heading(c,text=h);sales_tree.column(c,width=w)
sales_tree.pack(fill="both",expand=True,padx=12,pady=(0,12))

bottom=tk.Frame(content,bg=finance_bg(),highlightthickness=1,highlightbackground="#ffffff")
bottom.grid(row=1,column=0,columnspan=2,sticky="ew",pady=(0,2))
tk.Label(bottom,text="💡 Tipp: a hibás bejegyzést kijelölés után a Törlés gombbal eltávolíthatod.",font=("Segoe UI",9),bg=finance_bg(),fg=MUTED).pack(side="left",padx=12,pady=8)

finance["paint_spend"]=total_spend()
refresh_finance()

# Backup tab
bt=ttk.Frame(nb,padding=18);nb.add(bt,text="💾 Mentés")
ttk.Label(bt,text="💾 Biztonsági mentés",font=("Segoe UI",18,"bold")).pack(anchor="w")
def backup():
    fn=filedialog.asksaveasfilename(defaultextension=".json",filetypes=[("JSON","*.json")],initialfile="kreativ-keszlet-mentes.json")
    if fn:
        with open(fn,"w",encoding="utf-8") as f:json.dump({"data":data,"settings":settings,"finance":finance},f,ensure_ascii=False,indent=2)
        messagebox.showinfo(APP,"A biztonsági mentés elkészült.")
def restore():
    fn=filedialog.askopenfilename(filetypes=[("JSON","*.json")])
    if not fn:return
    try:
        d=read_json(fn,{})
        if "data" in d:data.clear();data.update(d["data"])
        if "settings" in d:settings.clear();settings.update(d["settings"])
        if "finance" in d:finance.clear();finance.update(d["finance"])
        data.setdefault("pencils",[]); data.setdefault("shopping",[])
        save();save_settings();save_finance();refresh();refresh_finance();refresh_pencils();refresh_fav_pencils();refresh_shop();refresh_dashboard();refresh_background();update_texts()
        messagebox.showinfo(APP,"A biztonsági mentést visszaállítottuk.")
    except Exception as e:messagebox.showerror(APP,f"Nem sikerült: {e}")
def print_inventory():
    fn=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Szövegfájl","*.txt")],initialfile="kreativ-keszlet-lista.txt")
    if not fn:return
    lines=["KREATÍV KÉSZLET", "="*50, ""]
    for x in data.get("items",[]):
        lines.append(f"{x.get('name','')} | {x.get('category','')} | {x.get('kind','')} | {x.get('qty',0)} {x.get('unit','db')} | {x.get('place','')}")
    with open(fn,"w",encoding="utf-8") as f:f.write("\n".join(lines))
    messagebox.showinfo(APP,"A készletlista elkészült.")

ttk.Button(bt,text="🖨️ Készletlista mentése",command=print_inventory).pack(anchor="w",pady=7)
ttk.Button(bt,text="💾 Biztonsági mentés készítése",style="Accent.TButton",command=backup).pack(anchor="w",pady=7)
ttk.Button(bt,text="↩️ Biztonsági mentés visszaállítása",command=restore).pack(anchor="w",pady=7)

# Appearance editor
def apply_glass_colors():
    global GLASS, GLASS2
    GLASS,GLASS2=glass_colors()
    style.configure("TNotebook",background=GLASS)
    style.configure("Treeview",background=GLASS2,fieldbackground=GLASS2,foreground=INK)
    style.configure("Glass.TFrame",background=GLASS)
    style.configure("Glass2.TFrame",background=GLASS2)
    for widget in (main,header,header_text,btns,message_footer):
        try: widget.configure(bg=GLASS)
        except: pass

def update_texts():
    # A fejléc címe és alcíme külön is elmenthető. Üresen hagyva ténylegesen eltűnnek.
    title=settings.get("title", "").strip()
    subtitle=settings.get("subtitle", "").strip()
    root.title(APP)
    header_title.config(text=title)
    header_subtitle.config(text=subtitle)
    # Ha a felhasználó kitörölte a szöveget, a hozzá tartozó Label se foglaljon helyet.
    if title:
        if not header_title.winfo_ismapped():
            header_title.pack(anchor="w")
    else:
        if header_title.winfo_ismapped():
            header_title.pack_forget()
    if subtitle:
        if not header_subtitle.winfo_ismapped():
            header_subtitle.pack(anchor="w")
    else:
        if header_subtitle.winfo_ismapped():
            header_subtitle.pack_forget()
    apply_glass_colors()
    refresh_background()
def appearance_editor():
    w=tk.Toplevel(root);w.title("🎨 Megjelenés szerkesztése");w.geometry("980x650");w.minsize(900,600)
    left=ttk.Frame(w,padding=20);left.pack(side="left",fill="y")
    right=tk.Frame(w,bg="#f3e7e8");right.pack(side="right",fill="both",expand=True)
    ttk.Label(left,text="🎨 Saját megjelenés",font=("Segoe UI",19,"bold")).pack(anchor="w")
    ttk.Label(left,text="A jobb oldalon élő előnézetet látsz.",foreground=MUTED).pack(anchor="w",pady=(2,18))

    ttk.Label(left,text="Fejléc címe").pack(anchor="w",pady=(0,3))
    title_var=tk.StringVar(value=settings.get("title", ""))
    ttk.Entry(left,textvariable=title_var).pack(fill="x",pady=(0,8))
    ttk.Label(left,text="Fejléc alcíme").pack(anchor="w",pady=(0,3))
    subtitle_var=tk.StringVar(value=settings.get("subtitle", ""))
    ttk.Entry(left,textvariable=subtitle_var).pack(fill="x",pady=(0,10))

    ttk.Label(left,text="Felületek áttetszősége").pack(anchor="w",pady=(2,0))
    opacity=tk.IntVar(value=int(settings.get("glass_opacity",35)))
    ttk.Scale(left,from_=15,to=70,variable=opacity,command=lambda _:preview()).pack(fill="x")
    opacity_value=tk.Label(left,text=f"{opacity.get()}%",bg="#f3e7e8",fg=INK,font=("Segoe UI",9))
    opacity_value.pack(anchor="e")
    def update_opacity_label(*_):
        opacity_value.config(text=f"{int(float(opacity.get()))}%")
    opacity.trace_add("write",update_opacity_label)
    ttk.Label(left,text="Minél kisebb az érték, annál jobban érvényesül a festmény. (Tkinterben ez üveges hatásként van szimulálva.)",foreground=MUTED,wraplength=330).pack(anchor="w",pady=(0,10))

    def choose():
        p=filedialog.askopenfilename(parent=w,filetypes=[("Képek","*.png;*.jpg;*.jpeg;*.bmp;*.webp")])
        if p:
            try:
                with open(p,"rb") as f:settings["image"]=base64.b64encode(f.read()).decode("ascii")
                settings["image_name"]=os.path.basename(p)
                global bg_cache_key, bg_source_pil
                bg_cache_key=None; bg_source_pil=None
                preview()
            except Exception as e:messagebox.showerror(APP,str(e),parent=w)
    ttk.Button(left,text="🖼️ Saját festmény kiválasztása",style="Accent.TButton",command=choose).pack(fill="x",pady=5)
    ttk.Label(left,text="Háttér sötétítése").pack(anchor="w",pady=(15,0))
    dark=tk.IntVar(value=int(settings.get("image_dark",12)));ttk.Scale(left,from_=0,to=55,variable=dark,command=lambda _:preview()).pack(fill="x")
    ttk.Label(left,text="Háttérszín (ha nincs kép)").pack(anchor="w",pady=(15,0))
    bgv=tk.StringVar(value=settings.get("bg","#f4efe8"))
    ttk.Button(left,text="Szín kiválasztása",command=lambda:pickbg()).pack(anchor="w",pady=4)
    def pickbg():
        c=colorchooser.askcolor(initialcolor=bgv.get(),parent=w)
        if c and c[1]:bgv.set(c[1]);preview()
    ttk.Label(left,text="Vicces üzenetek",font=("Segoe UI",11,"bold")).pack(anchor="w",pady=(20,4))
    mlb=tk.Listbox(left,height=6,width=38);mlb.pack(fill="x")
    for m in settings["messages"]:mlb.insert("end",m)
    me=tk.StringVar();ttk.Entry(left,textvariable=me).pack(fill="x",pady=4)
    def madd():
        if me.get().strip():settings["messages"].append(me.get().strip());mlb.insert("end",me.get().strip());me.set("")
    def mdel():
        s=mlb.curselection()
        if s:mlb.delete(s[0]);settings["messages"].pop(s[0])
    row=ttk.Frame(left);row.pack(fill="x");ttk.Button(row,text="＋",command=madd).pack(side="left");ttk.Button(row,text="Törlés",command=mdel).pack(side="left",padx=5)
    def saveapp():
        settings["title"]=title_var.get().strip()
        settings["subtitle"]=subtitle_var.get().strip()
        settings["image_dark"]=int(dark.get())
        settings["glass_opacity"]=int(float(opacity.get()))
        apply_glass_colors()
        settings["bg"]=bgv.get()
        save_settings()
        global bg_cache_key
        bg_cache_key=None
        update_texts();w.destroy()
    ttk.Button(left,text="🌙 Esti kérdés kipróbálása",command=lambda: daily_question(force=True,mark=False)).pack(fill="x",pady=(5,4))
    ttk.Button(left,text="✓ Mentés",style="Accent.TButton",command=saveapp).pack(fill="x",pady=18)
    prev=tk.Frame(right,bg=bgv.get());prev.pack(fill="both",expand=True,padx=18,pady=18)
    ph=[None]
    def preview():
        for x in prev.winfo_children():x.destroy()
        prev.configure(bg=bgv.get())
        raw=settings.get("image","")
        if raw:
            try:
                pil=Image.open(io.BytesIO(base64.b64decode(raw))).convert("RGB")
                pil=ImageEnhance.Brightness(pil).enhance(max(.45,1-int(dark.get())/100))
                pw=max(500,prev.winfo_width());phh=max(400,prev.winfo_height());r=max(pw/pil.width,phh/pil.height)
                pil=pil.resize((int(pil.width*r),int(pil.height*r)),Image.LANCZOS)
                pil=pil.crop(((pil.width-pw)//2,(pil.height-phh)//2,(pil.width+pw)//2,(pil.height+phh)//2))
                ph[0]=ImageTk.PhotoImage(pil);tk.Label(prev,image=ph[0],bd=0).place(x=0,y=0,relwidth=1,relheight=1)
            except:pass
        # Üveges hatás: a panel színe a beállított áttetszőséghez közelít.
        op=int(float(opacity.get()))
        glass_preview=blend_hex("#ead3d5",GLASS,op/100.0)
        preview_title=title_var.get().strip()
        preview_subtitle=subtitle_var.get().strip()
        if preview_title:
            tk.Label(prev,text=preview_title,font=("Segoe UI",22,"bold"),bg=glass_preview,fg=INK,padx=12,pady=4).place(relx=.04,rely=.06,anchor="w")
        if preview_subtitle:
            tk.Label(prev,text=preview_subtitle,font=("Segoe UI",10),bg=glass_preview,fg=MUTED,padx=12,pady=2).place(relx=.04,rely=.13,anchor="w")
        tk.Label(prev,text=random.choice(settings["messages"]),font=("Segoe UI",11,"italic"),bg=glass_preview,fg=INK,padx=14,pady=10).place(relx=.5,rely=.88,anchor="center")
    w.after(150,preview)

# Daily 23:00-ish question: once per calendar day after 23:00 when app is opened,
# plus if already open, show at 23:00.
def daily_question(force=False, mark=True):
    now=datetime.now()
    key=now.strftime("%Y-%m-%d")
    path=os.path.join(os.path.expanduser("~"),"KreativKeszlet_napi.json")
    state=read_json(path,{"last":""})
    if not force and now.hour<23:return
    if not force and state.get("last")==key:return
    if mark:
        state["last"]=key
        with open(path,"w",encoding="utf-8") as f:json.dump(state,f)
    q=tk.Toplevel(root);q.title("🌙 Zsófi");q.geometry("500x255");q.resizable(False,False);q.transient(root);q.grab_set()
    q.configure(bg=GLASS)
    tk.Label(q,text="🌙 Zsófi, elmentél már aludni?",font=("Segoe UI",18,"bold"),bg=GLASS,fg=INK).pack(pady=(30,10))
    tk.Label(q,text="Ez az esti kérdés minden nap 23:00 után jelenik meg.",font=("Segoe UI",10),bg=GLASS,fg=MUTED).pack()
    row=tk.Frame(q,bg=GLASS);row.pack(pady=28)
    def ans(yes):
        q.destroy()
        msg="Ügyes vagy, Zsófi! Jó éjszakát! 🌙😴" if yes else "Sejtettem... még egy kicsit alkotunk? 😂"
        messagebox.showinfo("Zsófi",msg,parent=root)
    tk.Button(row,text="IGEN 😴",command=lambda:ans(True),bg="#f7e7e8",fg=INK,relief="flat",font=("Segoe UI",11,"bold"),padx=24,pady=11).pack(side="left",padx=8)
    tk.Button(row,text="NEM 😅",command=lambda:ans(False),bg=ACCENT,fg="white",relief="flat",font=("Segoe UI",11,"bold"),padx=24,pady=11).pack(side="left",padx=8)

def clock_check():
    now=datetime.now()
    if now.hour==23 and now.minute==0: daily_question()
    root.after(30000,clock_check)

# Init
threading.Thread(target=run_server,daemon=True).start()
refresh();refresh_finance();refresh_pencils();refresh_fav_pencils();refresh_shop();refresh_dashboard();update_texts()
rotate_message()
root.after(800,lambda:daily_question())
root.after(1000,clock_check)
root.mainloop()
