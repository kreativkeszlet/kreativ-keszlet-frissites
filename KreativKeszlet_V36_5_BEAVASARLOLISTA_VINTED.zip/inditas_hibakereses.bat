@echo off
cd /d "%~dp0"
echo Kreativ Keszlet hibakereses...
echo.
if exist "dist\KreativKeszlet\KreativKeszlet.exe" (
    "dist\KreativKeszlet\KreativKeszlet.exe"
) else (
    echo Eloszor futtasd a build_windows.bat fajlt.
)
echo.
pause
